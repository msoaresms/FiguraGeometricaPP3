Arquivo zip gerado em: 09/11/2017 18:15:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Grafo ou Figura Geométrica?!